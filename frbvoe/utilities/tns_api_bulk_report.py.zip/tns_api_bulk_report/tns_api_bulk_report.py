#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Avgust 2021

Developed and tested on:

- Linux 20.04 LTS
- Windows 10
- Python 3.8 (Spyder 4)

@author: Nikola Knezevic ASTRO DATA
"""

import os
import requests
import json
from collections import OrderedDict
import time    

#----------------------------------------------------------------------------------

#TNS                 = "www.wis-tns.org"
TNS                 = "sandbox.wis-tns.org"
url_tns_api         = "https://" + TNS + "/api"

TNS_BOT_ID          = "YOUR_BOT_ID_HERE"
TNS_BOT_NAME        = "YOUR_BOT_NAME_HERE"
TNS_API_KEY         = "YOUR_BOT_API_KEY_HERE"

list_of_filenames   = "Here put your list of filenames for uploading."
report_filename     = "Here put your report filename."
report_type         = "Here put 'tsv' or 'json' as the type of your report."
id_report           = "Here put your report ID for getting report's reply."

# current working directory
cwd                 = os.getcwd()
# folder containing files for uploading
upload_folder       = os.path.join(cwd, "files_for_uploading")
# folder containing tsv reports for sending
tsv_reports_folder  = os.path.join(cwd, "tsv_reports_for_sending")
# folder containing json reports for sending
json_reports_folder = os.path.join(cwd, "json_reports_for_sending")

# external http errors
ext_http_errors     = [403, 500, 503]
err_msg             = ["Forbidden", "Internal Server Error: Something is broken", "Service Unavailable"]

# how many seconds to sleep
SLEEP_SEC           = 5
# how many seconds to allow for the total waiting time for the reply
TIMEOUT             = 30

#----------------------------------------------------------------------------------

def set_bot_tns_marker():
    tns_marker = 'tns_marker{"tns_id": "' + str(TNS_BOT_ID) + '", "type": "bot", "name": "' + TNS_BOT_NAME + '"}'
    return tns_marker

def is_string_json(string):
    try:
        json_object = json.loads(string)
    except Exception:
        return False
    return json_object

def format_to_json(source):
    parsed = json.loads(source, object_pairs_hook = OrderedDict)
    result = json.dumps(parsed, indent = 4)
    return result

def print_status_code(response):
    json_string = is_string_json(response.text)
    if json_string != False:
        print ("status code ---> [ " + str(json_string['id_code']) + " - '" + json_string['id_message'] + "' ]\n")
    else:
        status_code = response.status_code
        if status_code in ext_http_errors:
            status_msg = err_msg[ext_http_errors.index(status_code)]
        else:
            status_msg = 'Undocumented error'
        print ("status code ---> [ " + str(status_code) + " - '" + status_msg + "' ]\n")

def upload_files():
    upload_url = url_tns_api + "/file-upload"
    tns_marker = set_bot_tns_marker()
    headers = {'User-Agent': tns_marker}
    api_data = {'api_key': TNS_API_KEY}
    files_data = {}
    for i in range(len(list_of_filenames)):
        file_name = list_of_filenames[i]
        file_path = os.path.join(upload_folder, file_name)
        key = 'files[' + str(i) + ']'     
        if file_name.lower().endswith(('.asci', '.ascii')):
            value = (file_name, open(file_path), 'text/plain')
        else:
            value = (file_name, open(file_path,'rb'), 'application/fits')
        files_data[key] = value
    response = requests.post(upload_url, headers = headers, data = api_data, files = files_data)
    return response

def upload():
    print ("Uploading files on the TNS...\n")
    response = upload_files()
    print_status_code(response)
    if response.status_code == 200:
        print ("The following files are uploaded on the TNS:\n")
        json_data = response.json()
        uploaded_files = json_data['data']
        for i in range(len(uploaded_files)):
            print ("- filename: '" + str(uploaded_files[i]) + "'")
        print ("\n")
    else:
        print ("Files are not uploaded on the TNS.\n")

def send_tsv_report():
    tsv_url = url_tns_api + "/csv-report"
    tns_marker = set_bot_tns_marker()
    headers = {'User-Agent': tns_marker}
    api_data = {'api_key': TNS_API_KEY}
    tsv_file_path = os.path.join(tsv_reports_folder, report_filename)
    tsv_read = (report_filename, open(tsv_file_path, 'rb'))
    tsv_data = {'csv': tsv_read}
    response = requests.post(tsv_url, headers = headers, data = api_data, files = tsv_data)
    return response

def send_json_report():
    json_url = url_tns_api + "/bulk-report"
    tns_marker = set_bot_tns_marker()
    headers = {'User-Agent': tns_marker}
    json_file_path = os.path.join(json_reports_folder, report_filename)
    json_read = format_to_json(open(json_file_path).read())
    json_data = {'api_key': TNS_API_KEY, 'data': json_read}
    response = requests.post(json_url, headers = headers, data = json_data)
    return response

def send_report():
    print ("Sending '" + report_filename + "' to the TNS...\n")
    if report_type == "tsv":
        response = send_tsv_report()
    else:
        response = send_json_report()
    print_status_code(response)
    if response.status_code == 200:
        print ("The report was sent to the TNS.\n")
        json_data = response.json()
        report_id = json_data['data']['report_id']
        print ("Report ID = " + str(report_id) + "\n")
        return report_id
    else:
        print ("The report was not sent to the TNS.\n")
        return None

def send_reply():
    reply_url = url_tns_api + "/bulk-report-reply"
    tns_marker = set_bot_tns_marker()
    headers = {'User-Agent': tns_marker}
    reply_data = {'api_key': TNS_API_KEY, 'report_id': id_report}
    response = requests.post(reply_url, headers = headers, data = reply_data)
    return response

def reply():
    if id_report != None:
        print ("Sending reply for the report id " + str(id_report) + " ...\n")
        time.sleep(SLEEP_SEC)
        response = send_reply()
        counter = SLEEP_SEC        
        while True:
            if (response.status_code == 404) and (counter <= TIMEOUT):
                time.sleep(SLEEP_SEC)
                response = send_reply()
                counter = counter + SLEEP_SEC
            else:
                break
        print_status_code(response)
        try:
            feedback = json.dumps(response.json()['data']['feedback'], indent = 4)
            print ("feedback:\n")
            print (feedback + "\n")
        except Exception:
            print ("feedback: {}\n")

#----------------------------------------------------------------------------------

TNS_BOT_ID          = "YOUR_BOT_ID_HERE"
TNS_BOT_NAME        = "YOUR_BOT_NAME_HERE"
TNS_API_KEY         = "YOUR_BOT_API_KEY_HERE"

# Comment/Uncomment sections for testing the various examples:

"""
# EXAMPLE 1 (upload files)
list_of_filenames   = ["rel_file_1.png", "rel_file_2.jpg", "spectra_example.asci.txt",
                       "spectra_example.fits", "frb_region_file_example.fits"]
upload()
"""

"""
# EXAMPLE 2 (send TSV AT report)
report_filename     = "bulk_tsv_at_report.txt"
report_type         = "tsv"
id_report = send_report()
reply()
"""

"""
# EXAMPLE 3 (send JSON AT report)
report_filename     = "json_at_report.txt"
report_type         = "json"
id_report = send_report()
reply()
"""

"""
# EXAMPLE 4 (send TSV Classification report)
report_filename     = "bulk_tsv_classification_report.txt"
report_type         = "tsv"
id_report = send_report()
reply()
"""

"""
# EXAMPLE 5 (send JSON Classification report)
report_filename     = "json_classification_report.txt"
report_type         = "json"
id_report = send_report()
reply()
"""

"""
# EXAMPLE 6 (send JSON FRB report)
report_filename     = "json_frb_report.txt"
report_type         = "json"
id_report = send_report()
reply()
"""

"""
# EXAMPLE 7 (get reply)
id_report           = 78282
reply()
"""

#----------------------------------------------------------------------------------






